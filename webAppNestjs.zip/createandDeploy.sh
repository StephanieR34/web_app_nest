#!/bin/bash

az appservice plan create -n appserviceNestjs --sku F1

az webapp create -p appserviceNestjs -n webAppNestjs --runtime "node|14-lts"

az webapp deployment source config-zip -n webappnestjs --src webAppNestjs.zip