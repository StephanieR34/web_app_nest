# !/bin/bash
echo "var resource groupe create"
export ResourceGroup="tform-rrichardstephanie"

echo "var name webapp create"
export WebAppName="webappnestjs"

echo "var app service create"
export AppServiceName="appserviceNestjs"

echo "var file zip create"
export PathZipFile="webAppNestjs.zip"